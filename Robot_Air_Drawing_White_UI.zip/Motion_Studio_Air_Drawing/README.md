# Motion Studio — Robot vẽ theo tay

Nhấp đúp **`run.bat`**, chọn camera rồi bấm **Bật camera**. Giao diện giữ nền trắng. Robot vẽ theo từng điểm đang di chuyển; không chờ bạn vẽ xong hình mới vẽ lại.

1. Đưa **một bàn tay** vào hình, giữ đầu ngón trỏ trong **khung xanh**.
2. **Chụm ngón cái và ngón trỏ** ổn định ít nhất 5 frame để hạ bút. Di chuyển tay để vẽ. Các điểm đầu nét được giữ lại trong lúc xác nhận.
3. **Thả hai ngón ra** để nhấc bút ngay; lúc này di chuyển tay sẽ không tạo đường nối. Mất tay, ra ngoài vùng vẽ hoặc điểm mốc nhảy bất thường cũng nhấc bút.
4. Vẽ xong và nhấc bút: chương trình gắn nhãn **đường thẳng, tròn, vuông, chữ nhật, tam giác, elip** nếu đủ rõ. Nét tự do vẫn giữ nguyên. Các cạnh vẽ rời có đầu mút gần nhau cũng có thể ghép để nhận dạng hình.

Có thể chọn **Ngón trỏ để vẽ**: giơ ngón trỏ để hạ bút, giơ thêm ngón giữa để nhấc bút. Tay nên đủ sáng và không che đầu ngón.

- **Hoàn tác / Ctrl+Z**, **Xóa bản vẽ / Delete**, đổi màu/độ dày bút.
- **Lưu PNG/SVG**: lưu đúng nét đầu bút robot, không kèm ảnh webcam.
- **Hiện robot**: bật/tắt tay máy để xem giấy vẽ lớn hơn.
- **Tạm dừng / Space** nhấc bút; **Ngắt kết nối / Esc** giữ lại bản vẽ.
- **Vẽ bằng chuột**: giữ chuột trái trong khung xanh để thử cùng bộ điều khiển robot.
- **Xem minh họa**: điểm chuyển động tạo sẵn, có nhãn rõ; bản vẽ thật của bạn được giữ riêng khi xem demo.

Vùng camera và giấy robot có cùng tỷ lệ để hình tròn không bị kéo thành elip. Robot dùng động học nghịch 2 khâu; nét vẽ lấy từ đầu bút đã giải góc khớp. Chương trình có lọc rung, xử lý nhận dạng ngoài luồng giao diện, giữ các mẫu nét khi khung hiển thị bị bỏ qua. Nhãn hình là phép nhận dạng hình học gần đúng, không cam kết nhận đúng mọi nét vẽ tay.

Nếu không mở được camera: đóng Camera/Zoom/Teams, kiểm tra quyền Camera cho ứng dụng desktop của Windows hoặc chọn Camera 1/2/3. Có thể thử chuột/minh họa trước. Thư viện và mô hình được cài/tải lần đầu nếu thiếu; sau đó xử lý tại máy. Không tự ghi hình, không tạo báo cáo.

```powershell
.\.venv\Scripts\python.exe drawing_app.py
.\.venv\Scripts\python.exe drawing_app.py --demo
.\.venv\Scripts\python.exe drawing_app.py --mouse
.\.venv\Scripts\python.exe drawing_app.py --video ban_tay_ve.mp4
.\.venv\Scripts\python.exe -m unittest discover -s tests -p 'test_draw*.py' -v
```

Python đã kiểm tra: 3.11 64-bit có Tkinter. Bài Pose/Robot cũ còn ở `run_pose.bat`; bài cử chỉ/khối AR ở `run_gestures.bat` trong thư mục làm việc. Gói Air Drawing chứa riêng chương trình vẽ và các mô-đun dùng chung.

Mô hình: [MediaPipe Hand Landmarker](https://developers.google.com/edge/mediapipe/solutions/vision/hand_landmarker/python). [Ảnh bàn tay mẫu](https://storage.googleapis.com/mediapipe-assets/thumb_up.jpg) dùng kiểm tra mô hình trên một ảnh; không được lặp thành 5 frame để khẳng định đã nhận một động tác ổn định.
