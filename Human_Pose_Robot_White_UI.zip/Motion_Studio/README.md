# Motion Studio — Human Pose to Robot Motion

**Nhấp đúp `run.bat`**, chọn camera rồi bấm **Bật camera**. Giao diện nền trắng; hình webcam bên trái, cánh tay robot 2D bên phải.

- Đưa vai, khuỷu và cổ tay vào hình. Chỉ điều khiển khi cả 3 điểm đủ độ tin cậy; thiếu điểm sẽ giữ robot ở tư thế cuối và không phát lệnh mới.
- Giơ cổ tay cao hơn vai: **Giơ tay**. Đưa tay xuống: **Hạ tay**. Giơ tay rồi vẫy qua lại rõ ràng: **Vẫy tay**. Vẫy cần nhiều lần đổi chiều; giơ tay đứng yên không được tính là vẫy.
- Hành động cần ổn định ít nhất **5 frame liên tiếp**. Góc được làm mượt và tính đúng tỷ lệ khung hình bằng công thức tích vô hướng tại khuỷu. Góc hiển thị là góc 2D trong mặt phẳng ảnh, không phải phép đo góc khớp vật lý bằng thiết bị chuyên dụng.
- **Tay điều khiển** chọn trái/phải hoặc tự động. Trái/phải theo cơ thể người, không đổi tên khi bật ảnh gương.
- **Tạm dừng / Tiếp tục**, **Ngắt kết nối**, **Mở video** là các nút trực tiếp. **Space** tạm dừng; **Esc** ngắt kết nối.
- **Xem minh họa** chạy chuyển động tạo sẵn để xem giao diện/robot khi không có webcam; chế độ này được ghi nhãn rõ ràng, không phải kết quả nhận dạng camera.

Nếu camera không mở, đóng Camera/Zoom/Teams, kiểm tra quyền camera cho ứng dụng desktop của Windows, hoặc chọn Camera 1/2/3. Lần đầu chỉ cần mạng nếu thiếu thư viện hoặc mô hình; sau khi cài/tải xong, xử lý tại máy. Chương trình không tự ghi hình và không tạo báo cáo.

Python đã kiểm tra: **3.11 64-bit**, có Tkinter đi kèm. Môi trường riêng ở `.venv`.

```powershell
# Mở giao diện / xem minh họa
.\.venv\Scripts\python.exe pose_app.py
.\.venv\Scripts\python.exe pose_app.py --demo

# Mở video hoặc kiểm tra một ảnh (không lặp ảnh thành 5 frame)
.\.venv\Scripts\python.exe pose_app.py --video chuyen_dong.mp4
.\.venv\Scripts\python.exe pose_app.py --image artifacts\pose_sample.jpg

# Kiểm thử bài Pose/Robot
.\.venv\Scripts\python.exe -m unittest discover -s tests -p 'test_pose*.py' -v
```

Bài cử chỉ tay/khối AR trước đó vẫn mở bằng `run_gestures.bat` trong thư mục làm việc. Gói ZIP bài Pose chỉ chứa phần Pose/Robot.

Nguồn mô hình/API: [Google MediaPipe Pose Landmarker](https://developers.google.com/edge/mediapipe/solutions/vision/pose_landmarker/python). [Ảnh tư thế mẫu của MediaPipe](https://storage.googleapis.com/mediapipe-assets/pose.jpg) chỉ dùng kiểm tra nhận dạng một khung hình.
