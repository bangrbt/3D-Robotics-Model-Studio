# Nhận dạng cử chỉ tay qua webcam

Chạy **`run.bat`**. Chương trình dùng MediaPipe Gesture Recognizer, nhận một bàn tay tại một thời điểm và phân biệt 7 kiểu cử chỉ. Lần đầu cần mạng để cài thư viện/tải mô hình; sau đó xử lý tại máy.

## Hứng khối trên tay và bung lấp lánh

Khối 3D được ghép **ngay lên lòng bàn tay trong ảnh webcam**, bám theo vị trí tay và thay đổi kích thước theo độ lớn của tay trên hình. Không cần dùng bảng 3D riêng.

1. **Xòe bàn tay**, giữ yên ít nhất 5 frame: khối xuất hiện trên lòng bàn tay. Hơi hướng lòng bàn tay về phía camera để nhận dạng dễ hơn.
2. **Nắm tay**, giữ ít nhất 5 frame: khối co lại, sáng lên và có hạt năng lượng bao quanh.
3. **Xòe tay trở lại**, giữ ít nhất 5 frame: khối bung thành 140 hạt sáng 3D, có ánh sao và quầng sáng. Hạt bay từ vị trí thả, tan dần trong khoảng 2,4 giây rồi khối tái tạo trên tay.

Có thể giơ **ngón cái + trỏ + út** ổn định để bung trực tiếp khi đang hứng khối. Giữ nguyên cử chỉ không làm nổ lặp. Mất tay thì ẩn hiệu ứng và hủy trạng thái tích năng lượng; xòe tay ổn định để hứng lại. **R** đặt lại toàn bộ khối/hiệu ứng. Khung xương tay mặc định tắt; **L** bật để kiểm tra theo dõi.

| Cử chỉ | Lệnh hiển thị | Hiệu ứng 3D |
|---|---|---|
| Xòe tay | START / BẮT ĐẦU | Hứng/quay khối; bung tỏa nếu trước đó đã nắm tay |
| Nắm tay | STOP / DỪNG | Dừng quay và tích năng lượng |
| Trỏ ngón tay lên | MOVE_UP / ĐI LÊN | Nâng khối lên |
| Giơ ngón cái lên | ZOOM_IN / PHÓNG TO | Tăng kích thước |
| Úp ngón cái xuống | ZOOM_OUT / THU NHỎ | Giảm kích thước |
| Hai ngón chữ V | CHANGE_COLOR / ĐỔI MÀU | Đổi màu khối |
| Giơ ngón cái, trỏ và út | PARTICLES / BUNG LẤP LÁNH | Bung trực tiếp khối đang hứng |

Lệnh chỉ được phát sau **ít nhất 5 frame liên tiếp cùng cử chỉ**, mỗi frame có độ tin cậy ≥65%. Frame mất tay, không rõ hoặc không đủ tin cậy sẽ ngắt chuỗi. Giữ nguyên cử chỉ chỉ phát một lần; chuyển sang cử chỉ khác ổn định hoặc thả tay đủ 5 frame rồi làm lại để phát tiếp. Việc hiện khối, tích năng lượng và bung hạt đều qua bộ lọc 5 frame; vị trí khối cập nhật liên tục theo điểm mốc tay. Lệnh được hiện trên màn hình, in ra console và lưu `results/commands.csv`; sự kiện bung hạt lưu riêng ở `results/effects.csv` để không trộn vào số liệu so sánh cử chỉ.

## So sánh điều kiện thật

1. Dùng **G** chọn cử chỉ cần kiểm tra. Bảng so sánh chỉ tổng hợp cử chỉ đang chọn để so sánh công bằng.
2. Chọn **1**: ánh sáng bình thường; **2**: ánh sáng yếu; **3**: tay bị che khuất; **4/5/6**: khoảng cách khoảng 30/60/100 cm. Có thể nhấp vào dòng điều kiện trong bảng.
3. **Tự bố trí điều kiện thực tế**: giảm đèn, dùng vật che một phần ngón tay, hoặc đo khoảng cách từ bàn tay đến camera. Phím chọn chỉ gắn nhãn, không tự làm tối hay đo khoảng cách.
4. Bấm **T**, có 2 giây chuẩn bị, sau đó giữ đúng cử chỉ trong 4 giây đo. Bộ đếm 5 frame được đặt lại lúc bắt đầu đo.
5. Lặp cùng số lượt cho từng điều kiện, nên ít nhất 5 lượt/cử chỉ/điều kiện; giữ các yếu tố khác tương tự. Thử che cùng vị trí/mức che; kiểm soát camera tự điều chỉnh sáng nếu thiết bị hỗ trợ.
6. Bảng tự cập nhật: tỷ lệ frame nhận đúng, tỷ lệ lượt có lệnh đúng và không có lệnh sai, số lệnh sai, độ trễ trung bình đến lệnh đúng đầu tiên. **S** xuất `results/comparison.csv`; từng lượt tự lưu trong `results/trials.csv`.

Không phát hiện tay hoặc không rõ cử chỉ vẫn được tính là frame sai khi đang giữ cử chỉ mục tiêu. Không có lệnh đúng thì độ trễ để trống, không ghi bằng 0. Ô “—” nghĩa là chưa có dữ liệu, không phải độ chính xác bằng 0. Số sáng là độ sáng trung bình khung hình, không phải lux. Diện tích tay là tỷ lệ hộp bao 21 điểm mốc, không phải khoảng cách đo bằng cm.

**X** hủy lượt đang đo, **L** bật/tắt khung xương tay, **R** đặt lại cảnh 3D, **Q/Esc** thoát. Nhấp vào cửa sổ trước khi dùng phím. Webcam không ghi hình; chỉ lưu số liệu và sự kiện.

## Chạy bằng PowerShell

```powershell
cd C:\HRI
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe app.py

# Camera khác; tăng yêu cầu ổn định nếu muốn
.\.venv\Scripts\python.exe app.py --camera 1 --frames 8 --confidence 0.7

# Kiểm tra camera; chỉ đọc một frame rồi đóng
.\.venv\Scripts\python.exe app.py --check-camera

# Chạy từng frame thực của video
.\.venv\Scripts\python.exe app.py --video cu_chi.mp4

# Chạy video không mở giao diện
.\.venv\Scripts\python.exe app.py --video cu_chi.mp4 --headless

# Xem nhận dạng ảnh: chỉ 1 frame, tuyệt đối không phát lệnh
.\.venv\Scripts\python.exe app.py --preview anh_tay.jpg

# Kiểm thử
.\.venv\Scripts\python.exe -m unittest discover -s tests -v
```

Nếu webcam không mở: đóng Camera/Zoom/Teams, kiểm tra quyền camera cho ứng dụng desktop của Windows, thử `--camera 1`. Môi trường xây dựng trước đó không mở được camera 0; cần kiểm tra camera thật trên máy chạy. Python đã kiểm tra: 3.11 64-bit.

## So sánh tự động bằng ảnh/video có sẵn

`compare.py` dùng cùng đầu vào, tạo biến thể tối 25% cường độ, che 40% phần trên hộp bao tay và thay đổi tỷ lệ ảnh. Đây là **biến đổi số để thử nghiệm**, không thay cho đo ánh sáng yếu/che tay/khoảng cách vật lý với webcam. Khoảng cách gần/vừa/xa trong phép thử số không có giá trị cm.

```powershell
# Clip phải giữ đúng cử chỉ mục tiêu xuyên suốt; đọc tối đa 180 frame
.\.venv\Scripts\python.exe compare.py --video chu_v.mp4 --expected Victory

# Ảnh tĩnh chỉ đo nhận dạng, không đánh giá ổn định/phát lệnh
.\.venv\Scripts\python.exe compare.py --image anh_tay.jpg --expected Thumb_Up
```

Xuất `results/simulation.csv`, JSON cùng tên và ảnh đầu vào đã biến đổi. Không trộn kết quả mô phỏng vào bảng điều kiện thực. Không lặp ảnh tĩnh thành 5 frame để khẳng định đã có cử chỉ ổn định.

Mã chính: `vision.py` nhận dạng; `gestures.py` chặn/phát lệnh; `palm_ar.py` bám lòng bàn tay và bung hạt 3D; `scene3d.py` điều khiển khối; `experiments.py` đo và lưu số liệu; `ui.py` giao diện; `app.py` chạy chương trình.

Các tệp `artifacts/sample_*_comparison.csv` là kết quả thử **từng ảnh tĩnh mẫu**, mỗi điều kiện chỉ có 1 ảnh, không phải độ chính xác tổng quát hay đánh giá lệnh ổn định. Ảnh mẫu lấy từ kho công khai MediaPipe: [ngón cái lên](https://storage.googleapis.com/mediapipe-assets/thumb_up.jpg), [chữ V](https://storage.googleapis.com/mediapipe-assets/victory.jpg), [trỏ lên](https://storage.googleapis.com/mediapipe-assets/pointing_up.jpg). `artifacts/gesture_preview.jpg` là giao diện khi xử lý một ảnh, chưa phát lệnh.

`artifacts/palm_ar_demo.gif` minh họa hình thức khối/hạt trên [ảnh bàn tay mẫu](https://storage.googleapis.com/mediapipe-assets/woman_hands.jpg) đã cắt/xoay. Trạng thái xòe/nắm trong GIF **được mô phỏng để xem hiệu ứng**, không phải kết quả nhận dạng động tác trên ảnh tĩnh hay kiểm tra webcam. Có thể dựng lại bằng `python preview_ar.py --image artifacts/palm_sample.jpg` trong môi trường đã cài thư viện.

Nguồn: [MediaPipe Gesture Recognizer cho Python](https://developers.google.com/edge/mediapipe/solutions/vision/gesture_recognizer/python). Mô hình tải trực tiếp từ kho mô hình chính thức Google.
